﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crawford.Tests
{
    public class LoggerFake: ILogger
    {
        public void SafeLog(string message)
        {
            return;
        }
    }
}
