﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Web.UI.WebControls;

namespace Crawford.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestLogin()
        {
            var logger = new LoggerFake();
            var dbConnector = new DbConnectorFake();
            var processor = new Processor(dbConnector, logger);
            var lblMessage = new Label();
            var userId = processor.CheckUserLogin("", "", lblMessage);

            Assert.AreEqual(userId, "1");
            Assert.AreEqual(lblMessage.Text, Repository.LoggedIn);
        }
    }
}
