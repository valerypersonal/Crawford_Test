﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Crawford.Tests
{
    public class DbConnectorFake: IDbConnector
    {
        public DataTable CheckUserLogin(string userName, string password)
        {
            var dbTable = new DataTable();
            dbTable.Columns.Add("UserId");
            dbTable.Rows.Add("1");
            return dbTable;
        }

        public DataTable GetLossTypes(int userId)
        {
            var dbTable = new DataTable();
            dbTable.Columns.Add("LossTypeId");
            dbTable.Rows.Add("1");
            return dbTable;
        }
    }
}
