﻿namespace Crawford
{
    public static class Repository
    {
        public static string UserNotFound = "Either user name or password is incorrect.";
        public static string LoggedIn = "You have successfully logged in. Press Continue to see your Loss Types.";
        public static string GeneralError = "The server encounter an error, you may have better chance later.";
    }
}