﻿using System;
using System.Configuration;

namespace Crawford
{
    public partial class UserLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                return;

            var logger = new Logger(ConfigurationManager.AppSettings["log file name"]);
            var dbConnector = new DbConnector(ConfigurationManager.ConnectionStrings["CrawfordConnectionString"].ConnectionString, logger);
            var processor = new Processor(dbConnector, logger);
            var userId = processor.CheckUserLogin(tbUserName.Text, tbPassword.Text, lblMessage);
            if (!string.IsNullOrEmpty(userId))
            {
                Server.Transfer("LossTypes.aspx?userId="+userId);
            }
        }
    }
}