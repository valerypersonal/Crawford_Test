﻿using System.Data;

namespace Crawford
{
    public interface IDbConnector
    {
        //Task<DataTable> CheckUserLogin(string userName, string password);
        DataTable CheckUserLogin(string userName, string password);
        //Task<DataTable> GetLossTypes(int userId);
        DataTable GetLossTypes(int userId);
    }
}