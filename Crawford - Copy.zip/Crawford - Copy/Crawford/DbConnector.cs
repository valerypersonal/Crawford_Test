﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Crawford
{
    public class DbConnector: IDbConnector
    {
        private SqlCommand sqlCmd;
        private readonly ILogger _logger;

        public DbConnector(string connectionStr, ILogger logger)
        {
            var sqlConn = new SqlConnection(connectionStr);
            sqlCmd = new SqlCommand
            {
                Connection = sqlConn
            };
            _logger = logger;
        }

        //public async Task<bool> CheckUserLogin(string userName, string password)
        public DataTable CheckUserLogin(string userName, string password)
        {
            try
            {
                sqlCmd.CommandText = @"select *
                                    from Users_
                                    where Active = 1
                                    and UserName = @UserName
                                    and [Password] = @Password";
                sqlCmd.Parameters.AddWithValue("@UserName", userName);
                sqlCmd.Parameters.AddWithValue("@Password", password);
                //await sqlCmd.Connection.OpenAsync();
                sqlCmd.Connection.Open();
                return GetDataTable(sqlCmd);
            }
            catch (Exception ex)
            {
                _logger.SafeLog($"There was an exception in DbConnector.CheckUserLogin: {ex.Message}");
                return null;
            }
        }

        //public async Task<DataTable> GetLossTypes(int userId)
        public DataTable GetLossTypes(int userId)
        {
            try
            {
                sqlCmd.CommandText = @"select lt.LossTypeId, lt.LossTypeCode, lt.LossTypeDescription, lt.CreatedDate, lt.LastUpdatedDate
                                        from Users u
                                        inner join Claims c on u.UserId = c.CreatedId
                                        inner join LossTypes lt on lt.LossTypeId = c.LossTypeId
                                        where u.UserId = @UserId";
                sqlCmd.Parameters.AddWithValue("@UserId", userId);
                //await sqlCmd.Connection.OpenAsync();
                sqlCmd.Connection.Open();
                return GetDataTable(sqlCmd);
            }
            catch (Exception ex)
            {
                _logger.SafeLog($"There was an exception in DbConnector.GetLossTypes: {ex.Message}");
                return null;
            }
        }

        private DataTable GetDataTable(SqlCommand sqlCmd)
        {
            try
            {
                var dbTable = new DataTable();
                var sqlAdapt = new SqlDataAdapter(sqlCmd);
                sqlAdapt.Fill((dbTable));
                sqlCmd.Connection.Close();
                sqlAdapt.Dispose();
                return dbTable;
            }
            catch (Exception ex)
            {
                _logger.SafeLog($"There was an exception in DbConnector.GetDataTable: {ex.Message}");
                return null;
            }
        }
    }
}