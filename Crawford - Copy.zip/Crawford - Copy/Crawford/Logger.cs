﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Crawford
{
    public class Logger: ILogger
    {
        private string _fileName;

        public Logger(string fileName)
        {
            _fileName = fileName;
            var logLocation = Path.GetDirectoryName(fileName);
            if (logLocation != null && !Directory.Exists(logLocation))
                Directory.CreateDirectory(logLocation);
        }
        public void SafeLog(string message)
        {
            using (StreamWriter sw = File.AppendText(_fileName))
            {
                sw.WriteLine(message);
            }
        }
    }
}