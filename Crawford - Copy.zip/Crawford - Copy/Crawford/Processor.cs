﻿using System;
using System.Web.UI.WebControls;

namespace Crawford
{
    public class Processor
    {
        private readonly IDbConnector _dbConnector;
        private readonly ILogger _logger;

        public Processor(IDbConnector dbConnector, ILogger logger)
        {
            _dbConnector = dbConnector;
            _logger = logger;

        }
        public string CheckUserLogin(string userName, string password, Label lblMessage)
        {
            try
            {
                var dbTable = _dbConnector.CheckUserLogin(userName, password);
                if (dbTable == null)
                {
                    _logger.SafeLog("There was an error in Processor.CheckUserLogin: dbConnector returns null.");
                    lblMessage.Text = Repository.GeneralError;
                    return null;
                }
                if (dbTable.Rows.Count == 0)
                {
                    lblMessage.Text = Repository.UserNotFound;
                    return null;
                }

                lblMessage.Text = Repository.LoggedIn;
                var userId = dbTable.Rows[0]["UserId"].ToString();
                return userId;
            }
            catch (Exception ex)
            {
                _logger.SafeLog($"There was an exception in Processor.CheckUserLogin: {ex.Message}");
                lblMessage.Text = Repository.GeneralError;
                return null;
            }
        }

        public void ShowLossTypes(string userId, GridView gvLossTypes, Label lblMessage)
        {
            try
            {
                if (string.IsNullOrEmpty(userId))
                {
                    _logger.SafeLog("There was an error in Processor.ShowLossTypes: UserId was not provided.");
                    lblMessage.Text = Repository.GeneralError;
                    return;
                }
                var dbTable = _dbConnector.GetLossTypes(int.Parse(userId));
                if (dbTable == null)
                {
                    _logger.SafeLog("There was an error in Processor.ShowLossTypes: dbConnector returns null.");
                    lblMessage.Text = Repository.GeneralError;
                    return;
                }
                gvLossTypes.DataSource = dbTable;
                gvLossTypes.DataBind();
            }
            catch (Exception ex)
            {
                _logger.SafeLog($"There was an exception in Processor.ShowLossTypes: {ex.Message}");
                lblMessage.Text = Repository.GeneralError;
            }
        }
    }
}