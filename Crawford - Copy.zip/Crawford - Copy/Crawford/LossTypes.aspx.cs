﻿using System;
using System.Configuration;

namespace Crawford
{
    public partial class LossTypes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var logger = new Logger(ConfigurationManager.AppSettings["log file name"]);
            var dbConnector = new DbConnector(ConfigurationManager.ConnectionStrings["CrawfordConnectionString"].ConnectionString, logger);
            var processor = new Processor(dbConnector, logger);
            processor.ShowLossTypes(Page.Request.QueryString["userId"], gvLossTypes, lblMessage);
        }
    }
}