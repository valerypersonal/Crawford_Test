﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Crawford
{
    public interface ILogger
    {
        void SafeLog(string message);
    }
}